package com.example.android.marsphotos.data.db.entity

data class FoodImg (
    val id: Int,
    val fileName: String,
    val url: String,
)