package com.example.android.marsphotos.data.db.entity

data class Category(
    val id: Int,
    val name: String,
    val priority: Int,
)