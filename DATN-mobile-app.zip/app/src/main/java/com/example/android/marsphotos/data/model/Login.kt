package com.example.android.marsphotos.data.model

data class Login(
    var email: String = "",
    var password: String = ""
)