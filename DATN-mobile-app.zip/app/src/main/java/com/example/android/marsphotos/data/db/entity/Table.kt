package com.example.android.marsphotos.data.db.entity

data class Table(
    val id: Int,
    val name: String,
)